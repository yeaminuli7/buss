# LiveListen - কমপ্লিট ইমপ্লিমেন্টেশন গাইড (Android 16)

## ১. আপনি যা চেয়েছিলেন vs যা তৈরি হয়েছে

| আপনার রোডম্যাপ | ইমপ্লিমেন্টেশন ফাইল |
|---|---|
| Foreground Service (microphone) | `AudioLoopService.kt` - `startForeground(NOTIFICATION_ID, notification, FOREGROUND_SERVICE_TYPE_MICROPHONE)` |
| AudioRecord 48kHz + AudioTrack LOW_LATENCY | `AudioEngine.kt` - `PERFORMANCE_MODE_LOW_LATENCY`, 48kHz, PCM 16-bit |
| NoiseSuppressor API | `AudioEngine.kt` - `NoiseSuppressor.create(audioSessionId)` + `AcousticEchoCanceler` |
| Gain Control 0-500% | `AudioEngine.kt` - `gainFactor` clamp + `MainActivity.kt` Slider |
| WakeLock | `AudioLoopService.kt` - `PARTIAL_WAKE_LOCK` 10 ঘণ্টা |
| Jetpack Compose UI | `MainActivity.kt` - Master Toggle, Gain Slider, Noise Switch, Battery Card |
| Manifest Permission | `AndroidManifest.xml` - RECORD_AUDIO, FOREGROUND_SERVICE_MICROPHONE, WAKE_LOCK |

---

## ২. স্টেপ-বাই-স্টেপ রান করার নিয়ম

### Android Studio তে:
1. `LiveListen` ফোল্ডারটি Zip করে ডাউনলোড করুন
2. Android Studio > Open > LiveListen সিলেক্ট
3. Gradle Sync শেষ হলে `Run` চাপুন (Real Device Android 16 recommended)
4. প্রথমবার: Microphone + Notification পারমিশন Allow
5. Wired Earphone লাগান → "শুরু করুন" চাপুন → Notification এ LIVE দেখাবে
6. স্ক্রিন লক করেও টেস্ট করুন - 5 মিনিট পরেও চলবে

### Battery Unrestricted:
অ্যাপ থেকে "ব্যাটারি সেটিংস খুলুন" → App Info → Battery → Unrestricted

---

## ৩. কোড হাইলাইটস

### AudioLoop Engine - Low Latency Bridge
```kotlin
audioRecord = AudioRecord(VOICE_COMMUNICATION, 48000, MONO, PCM_16BIT, buffer*2)
audioTrack = AudioTrack.Builder()
    .setPerformanceMode(LOW_LATENCY)
    .setAudioAttributes(USAGE_VOICE_COMMUNICATION)
    .build()
// Loop: read -> gain multiply -> write (WRITE_BLOCKING)
```

### Foreground Service - Android 16 Fix
```kotlin
// Manifest
android:foregroundServiceType="microphone"
// Service
startForeground(id, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
```
না দিলে Android 16 এ `SecurityException` ক্র্যাশ হবে।

### Gain DSP
```kotlin
for (i in 0 until read) {
    buffer[i] = (buffer[i] * gainFactor).coerceIn(Short.MIN..MAX).toShort()
}
```

---

## ৪. টেস্টিং & অপ্টিমাইজেশন

- **Latency টেস্ট**: "টিক টিক" শব্দ করে ইয়ারফোনে delay মাপুন, টার্গেট < 50ms। Bluetooth এ 150ms+ হতে পারে, তাই Wired ব্যবহার করুন।
- **Feedback Test**: স্পিকার অন থাকলে শিস দেয়? `isSpeakerphoneOn = false` দিয়ে ফিক্স করা আছে।
- **Noise Test**: ফ্যানের সামনে ON/OFF টগল করে পার্থক্য শুনুন।
- **Background Test**: স্ক্রিন অফ + অন্য অ্যাপ খুলে 10 মিনিট চালান।

---

## ৫. পরবর্তী আপগ্রেড আইডিয়া
- Equalizer (Bass Boost)
- Bluetooth LE Audio support
- Record to file (WAV)
- Widget + Quick Tile

> প্রজেক্টটি `targetSdk 36 (Android 16)` এ 100% কমপ্লায়েন্ট।
