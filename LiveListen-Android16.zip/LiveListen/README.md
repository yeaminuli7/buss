# LiveListen - Android 16 Real-Time Live Listening App

আপনার রোডম্যাপ অনুযায়ী তৈরি সম্পূর্ণ প্রজেক্ট।

## ✨ ফিচার
- **রিয়েল-টাইম Low Latency**: AudioRecord → AudioTrack ব্রিজ, 48kHz, PCM 16-bit, PERFORMANCE_MODE_LOW_LATENCY
- **NoiseSuppressor + AEC**: হার্ডওয়্যার নয়েজ ফিল্টার
- **Gain Control**: 0% - 500% পর্যন্ত লাইভ অ্যামপ্লিফিকেশন
- **Foreground Service (microphone)**: Android 16 SecurityException fix - `foregroundServiceType="microphone"`
- **WakeLock**: স্ক্রিন লকেও প্রসেসর সচল
- **Battery Optimization**: Unrestricted prompt
- **Jetpack Compose UI**: Master Toggle, Gain Slider, Noise Switch

## 📱 Android 16 সতর্কতা (Implemented)
1. Manifest এ `FOREGROUND_SERVICE_MICROPHONE` ডিক্লেয়ার
2. Service এ `android:foregroundServiceType="microphone"`
3. startForeground() এ `FOREGROUND_SERVICE_TYPE_MICROPHONE` flag
4. Runtime Permission: RECORD_AUDIO + POST_NOTIFICATIONS (Android 13+)
5. AudioSource.VOICE_COMMUNICATION + MODE_IN_COMMUNICATION for routing

## 🚀 Build
1. Android Studio Iguana+ খুলুন
2. `LiveListen` ফোল্ডার Open করুন
3. Gradle Sync → Run on device (Android 16 emulator / real device)
4. Wired Earphone লাগিয়ে "শুরু করুন" চাপুন

## 🔧 টেস্টিং চেকলিস্ট
- [ ] Latency < 50ms?
- [ ] Screen off 5 min পরেও Notification আছে?
- [ ] NoiseSuppressor ON/OFF পার্থক্য?
- [ ] Gain 300%+ তে distortion ক্ল্যাম্প হচ্ছে?
- [ ] Speakerphone OFF (feedback নেই)?

## 📂 Structure
```
app/src/main/java/com/livelisten/app/
├── MainActivity.kt      -> Compose UI + Permission
├── AudioLoopService.kt  -> Foreground Service + WakeLock + Notification
├── AudioEngine.kt       -> Core AudioRecord/AudioTrack + DSP
└── AndroidManifest.xml  -> Android 16 permissions
```

> **ফিডব্যাক প্রিভেনশন**: সবসময় Wired headset ব্যবহার করুন। Bluetooth এ latency বেশি।
