package com.livelisten.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.util.Log
import kotlinx.coroutines.isActive
import kotlin.coroutines.coroutineContext

/**
 * AudioEngine: Real-time passthrough from mic -> earphone with minimal latency
 * Android 16 compatible, uses low-latency buffer sizing
 */
class AudioEngine {

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var agc: AutomaticGainControl? = null

    @Volatile var gainFactor: Float = 1.5f // Default 150%
    @Volatile var isNoiseSuppressionEnabled: Boolean = true

    private val sampleRate = 48000 // Modern devices prefer 48kHz for low latency. fallback 44100 if needed
    private val channelIn = AudioFormat.CHANNEL_IN_MONO
    private val channelOut = AudioFormat.CHANNEL_OUT_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT

    var isRunning = false
        private set

    fun isAvailable(): Boolean = isRunning

    suspend fun startLoop() {
        if (isRunning) return
        isRunning = true
        Log.d("AudioEngine", "Starting audio loop: $sampleRate Hz, gain=$gainFactor, NS=$isNoiseSuppressionEnabled")

        val minRecordBuf = AudioRecord.getMinBufferSize(sampleRate, channelIn, encoding)
        val minTrackBuf = AudioTrack.getMinBufferSize(sampleRate, channelOut, encoding)

        // Use 2x min buffer for stability but keep latency low
        val recordBufSize = minRecordBuf * 2
        val trackBufSize = minTrackBuf * 2

        if (minRecordBuf == AudioRecord.ERROR || minRecordBuf == AudioRecord.ERROR_BAD_VALUE) {
            Log.e("AudioEngine", "Invalid AudioRecord buffer size")
            isRunning = false
            return
        }

        // -------- AudioRecord (Mic Input) --------
        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, // Best for voice + echo cancellation support
            // alternative: MediaRecorder.AudioSource.MIC for raw
            sampleRate,
            channelIn,
            encoding,
            recordBufSize
        )

        // -------- NoiseSuppressor / AEC / AGC --------
        try {
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(audioRecord!!.audioSessionId).apply {
                    enabled = isNoiseSuppressionEnabled
                }
                Log.d("AudioEngine", "NoiseSuppressor enabled: ${noiseSuppressor?.enabled}")
            }
            if (AcousticEchoCanceler.isAvailable()) {
                echoCanceler = AcousticEchoCanceler.create(audioRecord!!.audioSessionId).apply {
                    enabled = true // Helps prevent feedback when speaker leaks
                }
            }
            // AGC off by default - we use manual gain
            if (AutomaticGainControl.isAvailable()) {
                agc = AutomaticGainControl.create(audioRecord!!.audioSessionId).apply {
                    enabled = false
                }
            }
        } catch (e: Exception) {
            Log.w("AudioEngine", "AudioEffect init failed: ${e.message}")
        }

        // -------- AudioTrack (Earphone Output) --------
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(encoding)
            .setChannelMask(channelOut)
            .build()

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(audioAttributes)
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(trackBufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()

        // Force earphone routing if wired headset exists, otherwise earpiece/bluetooth
        // AudioManager will handle routing automatically; we encourage wired headset in UI
        audioRecord?.startRecording()
        audioTrack?.play()

        val buffer = ShortArray(recordBufSize / 2) // 16-bit = 2 bytes per sample

        try {
            while (coroutineContext.isActive && isRunning) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read > 0) {
                    // Apply gain in DSP layer: multiply each PCM sample
                    // Clamp to Short range to prevent distortion
                    if (gainFactor != 1.0f) {
                        for (i in 0 until read) {
                            val amplified = (buffer[i] * gainFactor).toInt()
                            buffer[i] = amplified.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                        }
                    }
                    // Write to output with blocking mode for minimal latency
                    audioTrack?.write(buffer, 0, read, AudioTrack.WRITE_BLOCKING)
                } else if (read == AudioRecord.ERROR_INVALID_OPERATION || read == AudioRecord.ERROR_BAD_VALUE) {
                    Log.e("AudioEngine", "AudioRecord read error: $read")
                    break
                }
            }
        } catch (e: Exception) {
            Log.e("AudioEngine", "Loop exception: ${e.message}", e)
        } finally {
            stopInternal()
        }
    }

    fun updateGain(newGain: Float) {
        gainFactor = newGain.coerceIn(0.0f, 5.0f) // 0x to 5x (0-500%)
    }

    fun setNoiseSuppression(enabled: Boolean) {
        isNoiseSuppressionEnabled = enabled
        try {
            noiseSuppressor?.enabled = enabled
        } catch (e: Exception) {
            Log.w("AudioEngine", "Failed to toggle NS: ${e.message}")
        }
    }

    fun stopLoop() {
        isRunning = false
        stopInternal()
    }

    private fun stopInternal() {
        try {
            noiseSuppressor?.release()
            echoCanceler?.release()
            agc?.release()
        } catch (_: Exception) {}
        noiseSuppressor = null
        echoCanceler = null
        agc = null

        try {
            audioRecord?.apply {
                if (recordingState == AudioRecord.RECORDSTATE_RECORDING) stop()
                release()
            }
        } catch (_: Exception) {}
        audioRecord = null

        try {
            audioTrack?.apply {
                if (playState == AudioTrack.PLAYSTATE_PLAYING) stop()
                release()
            }
        } catch (_: Exception) {}
        audioTrack = null

        isRunning = false
        Log.d("AudioEngine", "AudioEngine stopped and released")
    }
}
