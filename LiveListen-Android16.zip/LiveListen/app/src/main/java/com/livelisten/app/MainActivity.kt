package com.livelisten.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LiveListenTheme {
                LiveListenApp()
            }
        }
    }
}

@Composable
fun LiveListenTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1E88E5),
            secondary = Color(0xFF0D47A1),
            tertiary = Color(0xFF00ACC1),
            background = Color(0xFFF5F7FA),
            surface = Color.White
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveListenApp() {
    val context = LocalContext.current
    val activity = context as? ComponentActivity

    var isListening by remember { mutableStateOf(false) }
    var gain by remember { mutableStateOf(1.5f) } // 0.0 - 3.0
    var noiseFilter by remember { mutableStateOf(true) }
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    // Permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        hasPermission = perms[Manifest.permission.RECORD_AUDIO] == true
        if (!hasPermission) {
            Toast.makeText(context, "মাইক্রোফোন পারমিশন ছাড়া অ্যাপ চলবে না", Toast.LENGTH_SHORT).show()
        }
    }

    // Check notification permission for Android 13+
    fun ensurePermissionsAndStart() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        } else {
            hasPermission = true
        }
    }

    // Battery optimization request
    fun requestBatteryUnrestricted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = context.getSystemService(android.os.PowerManager::class.java)
            val pkg = context.packageName
            if (pm != null && !pm.isIgnoringBatteryOptimizations(pkg)) {
                try {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$pkg")
                    }
                    context.startActivity(intent)
                } catch (_: Exception) {
                    Toast.makeText(context, "Settings > Battery > Unrestricted করুন", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("LiveListen", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("Android 16 • Low Latency", fontSize = 11.sp, color = Color.Gray)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
            )
        },
        containerColor = Color(0xFFF5F7FA)
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Warning Card - Feedback Prevention
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF6C00))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "ফিডব্যাক এড়াতে অবশ্যই Wired ইয়ারফোন / Closed Earbud ব্যবহার করুন। স্পিকার চালু রাখবেন না।",
                        fontSize = 13.sp,
                        color = Color(0xFF5D4037),
                        lineHeight = 18.sp
                    )
                }
            }

            // Master Toggle Card
            Card(
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (isListening) Brush.verticalGradient(listOf(Color(0xFF1E88E5), Color(0xFF0D47A1)))
                            else Brush.verticalGradient(listOf(Color.White, Color.White))
                        )
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Animated mic icon
                    Box(
                        modifier = Modifier
                            .size(88.dp)
                            .clip(CircleShape)
                            .background(if (isListening) Color.White.copy(alpha = 0.2f) else Color(0xFFE3F2FD)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicOff,
                            contentDescription = null,
                            tint = if (isListening) Color.White else Color(0xFF1E88E5),
                            modifier = Modifier.size(44.dp)
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        if (isListening) "লাইভ লিসেনিং চালু" else "লাইভ লিসেনিং বন্ধ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = if (isListening) Color.White else Color(0xFF212121)
                    )
                    Text(
                        if (isListening) "স্ক্রিন লক হলেও চলবে • Notification দেখুন" else "শুরু করতে নিচের বাটনে চাপুন",
                        fontSize = 12.sp,
                        color = if (isListening) Color.White.copy(alpha = 0.9f) else Color.Gray
                    )
                    Spacer(Modifier.height(18.dp))

                    // Big Toggle Button
                    Button(
                        onClick = {
                            if (!hasPermission) {
                                ensurePermissionsAndStart()
                                // If still no permission, permission dialog will show
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                    return@Button
                                }
                                hasPermission = true
                            }
                            if (!isListening) {
                                // Start service
                                AudioLoopService.start(context, gain, noiseFilter)
                                isListening = true
                                requestBatteryUnrestricted()
                            } else {
                                AudioLoopService.stop(context)
                                isListening = false
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isListening) Color(0xFFD32F2F) else Color(0xFF1E88E5),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            if (isListening) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (isListening) "বন্ধ করুন" else "শুরু করুন",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isListening) {
                        Spacer(Modifier.height(8.dp))
                        // Live indicator pulse
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00E676))
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("LIVE • ${ (gain * 100).toInt() }% • ${if (noiseFilter) "NS ON" else "NS OFF"}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.9f))
                        }
                    }
                }
            }

            // Gain Slider Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF1E88E5))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("ইনপুট গেইন / অ্যামপ্লিফিকেশন", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("সাউন্ড কতটা বুস্ট হবে", fontSize = 11.sp, color = Color.Gray)
                        }
                        Spacer(Modifier.weight(1f))
                        Surface(color = Color(0xFFE3F2FD), shape = RoundedCornerShape(8.dp)) {
                            Text(
                                "${(gain * 100).toInt()}%",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0D47A1),
                                fontSize = 13.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Slider(
                        value = gain,
                        onValueChange = {
                            gain = it
                            if (isListening) {
                                // Send update to service without restart
                                val intent = Intent(context, AudioLoopService::class.java).apply {
                                    action = AudioLoopService.ACTION_UPDATE_GAIN
                                    putExtra(AudioLoopService.EXTRA_GAIN, it)
                                }
                                context.startService(intent)
                            }
                        },
                        valueRange = 0.0f..5.0f,
                        steps = 9, // 0.5 steps
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF1E88E5),
                            activeTrackColor = Color(0xFF1E88E5),
                            inactiveTrackColor = Color(0xFFE0E0E0)
                        )
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("0% (Mute)", fontSize = 11.sp, color = Color.Gray)
                        Text("500% (Max Boost)", fontSize = 11.sp, color = Color.Gray)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("টিপস: 150%-200% সাধারণত কণ্ঠ স্পষ্ট করে, 300%+ এ হিসিং বাড়তে পারে।", fontSize = 11.sp, color = Color(0xFF757575))
                }
            }

            // Noise Filter Switch
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color(0xFF00ACC1))
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("স্মার্ট নয়েজ সাপ্রেশন", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text("ফ্যান, বাতাস, হিসিং সাউন্ড কমায়", fontSize = 11.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = noiseFilter,
                            onCheckedChange = {
                                noiseFilter = it
                                if (isListening) {
                                    val intent = Intent(context, AudioLoopService::class.java).apply {
                                        action = AudioLoopService.ACTION_UPDATE_NS
                                        putExtra(AudioLoopService.EXTRA_NS, it)
                                    }
                                    context.startService(intent)
                                }
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF1E88E5))
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFE0F7FA))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF00838F), modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "NoiseSuppressor API • Hardware-accelerated • Android 16 compliant",
                            fontSize = 11.sp,
                            color = Color(0xFF006064)
                        )
                    }
                }
            }

            // Battery Optimization Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = Color(0xFF43A047))
                        Spacer(Modifier.width(10.dp))
                        Text("ব্যাকগ্রাউন্ড পার্সিস্টেন্স", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("স্ক্রিন বন্ধ থাকলেও চালু রাখতে Battery Optimization 'Unrestricted' করুন।", fontSize = 12.sp, color = Color.Gray)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            // Open battery settings
                            try {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("ব্যাটারি সেটিংস খুলুন")
                    }
                }
            }

            // Permissions Status
            if (!hasPermission) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MicOff, contentDescription = null, tint = Color(0xFFC62828))
                        Spacer(Modifier.width(10.dp))
                        Text("মাইক্রোফোন পারমিশন প্রয়োজন। 'শুরু করুন' চাপলে অনুমতি চাইবে।", fontSize = 13.sp, color = Color(0xFFB71C1C), modifier = Modifier.weight(1f))
                    }
                }
            }

            // Footer
            Text(
                "Made for Android 16 • ForegroundService (microphone) • WakeLock • Low-latency AudioTrack\nLatency target: < 50ms • SampleRate: 48kHz • PCM 16-bit Mono",
                fontSize = 10.sp,
                color = Color.Gray,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}
