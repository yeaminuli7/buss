package com.livelisten.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class AudioLoopService : Service() {

    companion object {
        const val CHANNEL_ID = "LiveListenChannel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_UPDATE_GAIN = "ACTION_UPDATE_GAIN"
        const val ACTION_UPDATE_NS = "ACTION_UPDATE_NS"
        const val EXTRA_GAIN = "extra_gain"
        const val EXTRA_NS = "extra_ns"

        fun start(context: Context, gain: Float, nsEnabled: Boolean) {
            val intent = Intent(context, AudioLoopService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_GAIN, gain)
                putExtra(EXTRA_NS, nsEnabled)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, AudioLoopService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private val binder = LocalBinder()
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var audioJob: Job? = null
    private val audioEngine = AudioEngine()

    inner class LocalBinder : Binder() {
        fun getService(): AudioLoopService = this@AudioLoopService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
        // Set audio mode to communication for low latency + routing
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = false // Force earphone/earpiece, prevent feedback
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val gain = intent.getFloatExtra(EXTRA_GAIN, 1.5f)
                val ns = intent.getBooleanExtra(EXTRA_NS, true)
                audioEngine.updateGain(gain)
                audioEngine.setNoiseSuppression(ns)
                startForegroundWithNotification(gain, ns)
                launchAudioLoop()
            }
            ACTION_STOP -> {
                stopAudioLoop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            ACTION_UPDATE_GAIN -> {
                val gain = intent.getFloatExtra(EXTRA_GAIN, audioEngine.gainFactor)
                audioEngine.updateGain(gain)
                updateNotification()
            }
            ACTION_UPDATE_NS -> {
                val ns = intent.getBooleanExtra(EXTRA_NS, audioEngine.isNoiseSuppressionEnabled)
                audioEngine.setNoiseSuppression(ns)
                updateNotification()
            }
        }
        return START_STICKY // Restart if killed by system
    }

    private fun startForegroundWithNotification(gain: Float, nsEnabled: Boolean) {
        val notification = buildNotification(gain, nsEnabled)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        Log.d("AudioLoopService", "Foreground started with mic type")
    }

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(audioEngine.gainFactor, audioEngine.isNoiseSuppressionEnabled))
    }

    private fun buildNotification(gain: Float, nsEnabled: Boolean): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, AudioLoopService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val gainPercent = (gain * 100).toInt()

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LiveListen চালু আছে • ${gainPercent}%")
            .setContentText(if (nsEnabled) "Noise Filter: ON • ইয়ারফোন ব্যবহার করুন" else "Noise Filter: OFF")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now) // Replace with custom icon
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "বন্ধ করুন", stopIntent)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "LiveListen Background Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "মাইক্রোফোন থেকে ইয়ারফোনে লাইভ অডিও পাস-থ্রু"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LiveListen::AudioWakeLock").apply {
            acquire(10 * 60 * 60 * 1000L) // 10 hours max
        }
        Log.d("AudioLoopService", "WakeLock acquired")
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        wakeLock = null
    }

    private fun launchAudioLoop() {
        if (audioJob?.isActive == true) return
        audioJob = serviceScope.launch {
            try {
                audioEngine.startLoop()
            } catch (e: Exception) {
                Log.e("AudioLoopService", "Audio loop crashed: ${e.message}", e)
            }
        }
    }

    private fun stopAudioLoop() {
        audioJob?.cancel()
        audioEngine.stopLoop()
        audioJob = null
        // Reset audio mode
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_NORMAL
    }

    fun updateGain(gain: Float) {
        audioEngine.updateGain(gain)
        updateNotification()
    }

    fun updateNoiseSuppression(enabled: Boolean) {
        audioEngine.setNoiseSuppression(enabled)
        updateNotification()
    }

    fun isEngineRunning(): Boolean = audioEngine.isAvailable()

    override fun onDestroy() {
        stopAudioLoop()
        releaseWakeLock()
        serviceScope.cancel()
        super.onDestroy()
        Log.d("AudioLoopService", "Service destroyed")
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Keep running - START_STICKY will handle restart
        // Do NOT stopSelf() here
    }
}
