package com.livelisten.app

import android.app.Application

class LiveListenApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
