# Keep AudioEngine
-keep class com.livelisten.app.** { *; }
